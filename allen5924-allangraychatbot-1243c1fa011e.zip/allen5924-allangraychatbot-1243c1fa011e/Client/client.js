var clients = {
	12345: {
		fullname: "Ronald D Bach",
		accounts: {
			AGRA12345: {
				AGBD: 1002,
				AGEF: 524,
				CCPF: 100,
				FBCB2: 2124
			},

			AGUT12345: {
				AGBF: 2342,
				IUSM: 123
			}
		},
	},

	0000: {
		fullname: "Allen Huang",
		accounts: {
			AGUT8888: {
				AGEF: 20000,
				FBCB2: 113
			},

			AGRA8080: {
				AGBF: 2478,
				SMSF: 100
			}
		},
	}
};

getClient = (cif) => {
	return JSON.parse(JSON.stringify(clients[cif]));
}

getClientAccounts = (cif) => {
	return JSON.parse(JSON.stringify(clients[cif].accounts));
}

getClientFunds = (cif) => {
	var funds = {};
	if(clients[cif] === undefined)
		return funds;

	for(account in clients[cif].accounts)
		for(fund in clients[cif].accounts[account])
			funds[fund] = clients[cif].accounts[account][fund];

	return funds;
}