var funds = require('../funds.json');
var factsheets = require('../factsheets.json');
var _ = require('lodash');


var currencySymbols = {
    "ZAR" : "R",
    "USD" : "$",
    "AUD" : "$",
    "GBP" : "£",
    "JPY" : "¥",
    "EUR" : "€"
}

getCurrencySymbol = (fund) => {
    return currencySymbols[fund.fund.currency];
}

getLatestPrice = (fund) => {
    var latestDate;
    var latestPrice;

    _.forIn(fund.pricesInCents, (price, date) => {
        currentDate = new Date(date);
        if(latestDate === undefined || currentDate > latestDate) {
            latestDate = currentDate;
            latestPrice = price / 100;
        }
    })

    latestPrice = latestPrice.toFixed(2);

    return (latestPrice + ' (' + latestDate.toDateString() + ')');
}

getFactSheetUrl = (fund) => {
    var factsheetUrl = factsheets[fund.fund.displayCode];

    if(factsheetUrl === undefined)
        factsheetUrl = factsheets[fund.fund.code];

    if(factsheetUrl === undefined)
        factsheetUrl = 'https://www.allangray.co.za/what-we-offer/unit-trusts/';

    return factsheetUrl;
}

determineFundCode = (classifier, message) => {
    classifications = classifier.getClassifications(message);

    if(classifications.length > 1) {
        highest_score = Math.max.apply(Math, classifications.map(c => {
            return c.value;
        }));

        classifications_with_high_score = classifications.filter(c => {
            return c.value === highest_score;
        });

        if(classifications_with_high_score.length > 1)
            return classifications_with_high_score;
        else 
            return classifications_with_high_score[0].label;
    }

    return classifier.classify(message);
}

findFundDataFromCode = (fundCode) => {
    return funds.find(key => {
        return key.fund.code.match(fundCode.toUpperCase());
    });
}

extractFundCodeFromText = (words) => {
    var foundFund;

    words = words.split(' ');
    words = words.filter(word => {return word.length > 3});

    words.forEach(w => {
        currentFoundFund = funds.find(key => {
            match = key.fund.code.match('^' + w.toUpperCase() + '$');
            return match ? match : key.fund.displayCode.match('^' + w.toUpperCase() + '$');
        });

        if(currentFoundFund !== undefined)
            foundFund = currentFoundFund;
    });

    return foundFund;
}


getFundNames = (fundCodes) => {
    names = fundCodes.map(option => {
        return findFundDataFromCode(option.label).fund.name;
    });
    return names;
}
