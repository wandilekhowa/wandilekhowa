var request = require('request');
var fund_utils = require('../Funds/fund');
var preferences = require('../Preferences/preferences');

const appToken = 'EAAI35SeSxmQBAA7Qc8p3lxYoBHCXUO1ZB7K9r48fFZBRyMetUpVcRefcvn3AU4aosHRZAoPHQhX8hvyIAja0hDetWoaR1VFH9UAQDsARaZCZAR4NgrjYh9bxx38Ny2EqHGQx5RnunEElZA2VS17C7ZAgqG7BMMPF3g4yHkbk1bhuQZDZD'

sendTextMessage = (sender, text) => {
    messageData = {
        text:text
    }

    sendMessage(messageData, sender);
}

sendFundsFollowed = (sender) => {
var followedFunds = Object.keys(getFundPreferences(sender));

var funds = followedFunds.map(fundCode => {
    if(getFundPreferences(sender)[fundCode] !== undefined)
        if(getFundPreferences(sender)[fundCode] === "follow")
            fundFollowLabel = "Unfollow"

    var fund = findFundDataFromCode(fundCode);
    return {
        "title": `${fund.fund.displayCode} price history`,
        "image_url": `http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/fund/${fund.fund.displayCode}.jpg`,
        "subtitle": `${fund.fund.name}`,
        "buttons": [{
            "type": "postback",
            "payload": `factsheet:${fund.fund.displayCode}`,
            "title": "Fund Factsheet"
        },{
            "type": "postback",
            "payload": `follow_fund:${fund.fund.displayCode}`,
            "title": `${fundFollowLabel}`
        }],
    }
});

messageData = {
    "attachment": {
        "type": "template",
        "payload": {
            "template_type": "generic",
            "elements": funds
        }
    }
}

if(funds.length > 0)
    sendMessage(messageData, sender);
else 
    sendTextMessage(sender, "You are not following any funds.");

}

sendFundPrice = (sender, fund) => {
    if(fund === undefined) {
        sendTextMessage(sender, "ERROR: attempted to send fund information but request type not fund.")
        throw "fund undefined";
    } else {
        var fundFollowLabel = "Follow";

        if(getFundPreferences(sender)[fund.fund.displayCode] !== undefined)
            if(getFundPreferences(sender)[fund.fund.displayCode] === "follow")
                fundFollowLabel = "Unfollow"

            messageData = {
                "attachment": {
                    "type": "template",
                    "payload": {
                        "template_type": "generic",
                        "elements": [{
                            "title": `${fund.fund.displayCode} price history`,
                            "image_url": `http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/fund/${fund.fund.displayCode}.jpg`,
                            "subtitle": `${fund.fund.name}`,
                            "buttons": [{
                                "type": "postback",
                                "payload": `factsheet:${fund.fund.displayCode}`,
                                "title": "Fund Factsheet"
                            },{
                                "type": "postback",
                                "payload": `follow_fund:${fund.fund.displayCode}`,
                                "title": `${fundFollowLabel}`
                            }],
                        }]
                    }
                }
            }

            sendMessage(messageData, sender);
        }
    }

    sendFoundFundOptions = (sender, foundFundCodes, requestType) => {
        if(fund === undefined) {
            sendTextMessage(sender, "ERROR: attempted to send fund suggestions but request type not fund.")
            throw "fund undefined";
        } else {
            sendTextMessage(sender,
                "I'm not sure which fund you're asking for, but I think it could be these. Please select the one you were looking for.")

            suggestions = foundFundCodes.map(option => {
                return {
                "title": `${findFundDataFromCode(option.label).fund.displayCode}`,
                "subtitle": findFundDataFromCode(option.label).fund.name,
                "buttons": [{
                    "type": 'postback', 
                    "title": "Select",
                    "payload": `fund_info:${option.label}`,
                    }]
                }
            });

            if(suggestions.length > 9)
                suggestions.length = 9;

        suggestions.push({
                    "title": "None of these?",
                    "subtitle": "Try the fund code (\"AGEF\") or more specific queries (\"Foord Equity Fund\")."
                });

         messageData = {
                "attachment": {
                    "type": "template",
                    "payload": {
                        "template_type": "generic",
                        "elements": suggestions
                    }
                }
            }
            sendMessage(messageData, sender);
        }
    }

    sendFundFactSheet = (sender, fund) => {
        if(fund === undefined) {
            sendTextMessage(sender, "ERROR: attempted to send fund factsheet but request type not fund.")
            throw "fund undefined";
        } else {
            messageData = {
                "attachment": {
                    "type": "template",
                    "payload": {
                        "template_type": "generic",
                        "elements": [{
                            "title": `${fund.fund.name} factsheet`,
                            "subtitle": "Get the latest factsheet",
                            "buttons": [{
                                "type": "web_url",
                                "url": getFactSheetUrl(fund),
                                "title": "Download"
                            },
                            {
                                "type": "postback",
                                "payload": "email:factsheet",
                                "title": "Email"
                            }
                            ],
                        }]
                    }
                }
            }

            sendMessage(messageData, sender);
        }
    }

    sendGreeting = (sender, name) => {
        sendTextMessage(sender, `Hello ${name}, The Allan Gray Messenger bot is here to help you access information quickly and easily.`);
        setTimeout(() => {
            sendAssistanceQuickReplies(sender);
        }, 500);
    }

    sendApology = (sender) => {
        sendTextMessage(sender, `Sorry, I do not understand what you meant.`);
        setTimeout(() => {
            sendAssistanceQuickReplies(sender);
        }, 500);
    }

    sendAssistanceQuickReplies = (sender) => {
        messageData = {
            "text":"How can we help you?",
            "quick_replies":[
            {
                "content_type":"text",
                "title":"Fund Info",
                "payload":"cta:fund"
            },
            {
                "content_type":"text",
                "title":"Forms",
                "payload":"cta:forms"
            },
            {
                "content_type":"text",
                "title":"Insights",
                "payload":"cta:insights"
            },
            {
                "content_type":"text",
                "title":"Publications",
                "payload":"cta:publications"
            },
            {
                "content_type":"text",
                "title":"Settings",
                "payload":"cta:settings"
            }
            ]
        }

        sendMessage(messageData, sender);
    }

    sendCSCPhoneNumber = (sender) => {
        messageData = {
            "attachment": {
                "type": "template",
                "payload": {
                    "template_type": "button",
                    "text":"Speak to a consultant in our Client Service Centre",
                    "buttons": [{
                        "type": "phone_number",
                        "payload": "+27860000654",
                        "title": "Call 0860 000 654"
                    }],
                }
            }
        }
        sendMessage(messageData, sender);
    }

    sendLatestNews = (sender) => {
        messageData = {
            "attachment": {
                "type": "template",
                "payload": {
                    "template_type": "generic",
                    "elements": [{
                        "title": "Allan Gray Insights",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/news_2016-06-14.png",
                        "subtitle": "allangray.co.za",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/offshore-investing/broaden-your-horizons-with-offshore-investments/",
                            "title": "Read insight"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/",
                            "title": "View All Insights"
                        }],
                    },
                    {
                        "title": "Allan Gray Insights",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/news_2016-05-31.png",
                        "subtitle": "allangray.co.za",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/companies/commodities-opportunity-or-risk/",
                            "title": "Read insight"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/",
                            "title": "View All Insights"
                        }],
                    },
                    {
                        "title": "Allan Gray Insights",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/news_2016-04-22.png",
                        "subtitle": "allangray.co.za",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/corporate-citizenship/allan-gray-appoints-new-directors/",
                            "title": "Read insight"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/",
                            "title": "View All Insights"
                        }],
                    },
                    {
                        "title": "Allan Gray Insights",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/news_2016-04-20.png",
                        "subtitle": "allangray.co.za",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/markets-and-economy/uncertainty-persists/",
                            "title": "Read insight"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/",
                            "title": "View All Insights"
                        }],
                    },
                    {
                        "title": "Allan Gray Insights",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/news_2016-04-01.png",
                        "subtitle": "allangray.co.za",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/companies/africa-ex-sa-equity-fund-finding-value-in-nigeria/",
                            "title": "Read insight"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/",
                            "title": "View All Insights"
                        }],
                    },
                    {
                        "title": "Allan Gray Insights",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/news_2016-03-31.png",
                        "subtitle": "allangray.co.za",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/personal-investing/what-happens-when-i-die/",
                            "title": "Read insight"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/latest-insights/",
                            "title": "View All Insights"
                        }],
                    }]
                }
            }
        }

        sendMessage(messageData, sender);
    }

    sendLatestPublications = (sender) => {
        messageData = {
            "attachment": {
                "type": "template",
                "payload": {
                    "template_type": "generic",
                    "elements": [{
                        "title": "Quarterly Commentary",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/publication_qc.png",
                        "subtitle": "Contains a range of in-depth articles on the investments we make on your behalf.",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/globalassets/documents-repository/manco/quarterly-commentary/Allan%20Gray%20Unit%20Trust%20Management%20Limited/Files/2016-Q1.pdf",
                            "title": "View Latest"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/literature-library/",
                            "title": "View All Literature"
                        }],
                    },
                    {
                        "title": "GrayIssue",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/publication_gi.png",
                        "subtitle": "Monthly one-page newsletter covering a wide-range of investment topics.",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/globalassets/documents-repository/manco/gray-issue/Allan%20Gray%20Unit%20Trust%20Management%20Limited/Files/Issue%20178%20-%20Mark%20Dunley-Owen,%20Commodities%20Opportunity%20or%20risk.pdf",
                            "title": "View Latest"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/literature-library/",
                            "title": "View All Literature"
                        }],
                    },
                    {
                        "title": "Annual Reports",
                        "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/publication_ar.png",
                        "subtitle": "Detailed overview of the performance of our unit trusts.",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/globalassets/documents-repository/manco/full-annual-report/Allan%20Gray%20Unit%20Trust%20Management%20Limited/Files/2015%20Annual%20Report.pdf",
                            "title": "View Latest"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/literature-library/",
                            "title": "View All Literature"
                        }],
                    }]
                }
            }
        }

        sendMessage(messageData, sender);
    }

    sendFormOptions = (sender) => {
        messageData = {
            "attachment": {
                "type": "template",
                "payload": {
                    "template_type": "generic",
                    "elements": [{
                        "title": "Individual Investors (1/3)",
                        "subtitle": "Forms for Individual Investors",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-unit-trust-1",
                            "title": "Unit Trusts"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-allan-gray-retirement-annuity-fund-2",
                            "title": "AGRA Fund"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-allan-gray-tax-free-investment-account-3",
                            "title": "AG Tax-Free Investment Account"
                        }],
                    }, {
                        "title": "Individual Investors (2/3)",
                        "subtitle": "Forms for Individual Investors",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-living-annuity-4",
                            "title": "Living Annuity"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-allan-gray-pension-and-provident-preservation-funds-5",
                            "title": "AG Pension and Prov. Preservation Funds"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-endowment-6",
                            "title": "Endowment"
                        }],
                    },  {
                        "title": "Individual Investors (3/3)",
                        "subtitle": "Forms for Individual Investors",
                        "buttons": [{
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-offshore-7",
                            "title": "Offshore"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-fund-lists-11",
                            "title": "Fund Lists"
                        }, {
                            "type": "web_url",
                            "url": "https://www.allangray.co.za/forms-and-documents/#1,panel-allan-gray-group-retirement-annuity-12",
                            "title": "AG Group RA"
                        }],
                    }, {
                        "title": "IFAs",
                        "subtitle": "Forms for Independent Financial Advisors",
                        "buttons": [{
                            "type": "web_url",
                            "title": "See All",
                            "url": "https://www.allangray.co.za/forms-and-documents/#2",
                        }],
                    }, {
                        "title": "Other",
                        "subtitle": "Misc Forms",
                        "buttons": [{
                            "type": "web_url",
                            "title": "See All",
                            "url": "https://www.allangray.co.za/forms-and-documents/#3",
                        }],
                    }]
                }
            }
        }

        sendMessage(messageData, sender);
    }

    sendAccountLinkingLogin = sender => {
    //URL is hardcoded for demo - need to change. possibly use express to get host etc.
    //i.e. fullUrl = req.protocol + '://' + req.get('host') + req.originalUrl;

    messageData =  {
        "attachment": {
          "type": "template",
          "payload": {
            "template_type": "generic",
            "elements": [{
              "title": "Secure Access Login",
              "subtitle": "Log in using your Allan Gray username and password to access your account.",
              "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/ag_auth.png",
              "buttons": [{
                "type": "account_link",
                "url": "https://sheltered-atoll-23074.herokuapp.com/login"
            }]
        }]
    }
}
}

sendMessage(messageData, sender);
}

sendAccountLinkingLogout = sender => {
    messageData =  {
        "attachment": {
          "type": "template",
          "payload": {
            "template_type": "generic",
            "elements": [{
              "title": "Secure Access Logout",
              "image_url": "http://allenhuangnet1.ipage.com/_misc/ag_chatbot/media/ag_auth.png",
              "buttons": [{
                "type": "account_unlink"
            }]
        }]
    }
}
}

sendMessage(messageData, sender);
}

sendSettings = sender => {
    messageData = {
        "attachment": {
            "type": "template",
            "payload": {
                "template_type": "button",
                "text":"Which setting would you like to change?",
                "buttons": [{
                    "type": "postback",
                    "payload": "settings:daily_update",
                    "title": "Daily Update Time"
                }, {
                    "type": "postback",
                    "payload": "settings:fund_follows",
                    "title": "Followed funds"
                }],
            }
        }
    }
    sendMessage(messageData, sender);
}

sendSettingTimeQuickReply = (sender) => {
    messageData = {
        "text":"Would you like to change your daily update time?",
        "quick_replies":[
        {
            "content_type":"text",
            "title":"08h00",
            "payload":"daily_update:08h00"
        },
        {
            "content_type":"text",
            "title":"10h00",
            "payload":"daily_update:10h00"
        },
        {
            "content_type":"text",
            "title":"14h00",
            "payload":"daily_update:14h00"
        },
        {
            "content_type":"text",
            "title":"17h00",
            "payload":"daily_update:17h00"
        },
        {
            "content_type":"text",
            "title":"21h00",
            "payload":"daily_update:21h00"
        },
        {
            "content_type":"text",
            "title":"turn off",
            "payload":"daily_update:delete"
        }]
    }

    sendMessage(messageData, sender);
}

 sendClientCard = (sender, client) => {
    messageData = {
        "attachment": {
            "type": "template",
            "payload": {
                "template_type": "generic",
                "elements": [{
                    "title": `${client.fullname} - ${client.cif}`,
                    "subtitle": `Total Investment Value: ${client.netWorth}\n(as at ${client.lastUpdate})`,
                    "buttons": [{
                        "type": "postback",
                        "payload": `cif:accounts:${client.cif}`,
                        "title": "View Accounts"
                    },{
                        "type": "postback",
                        "payload": `cif:funds:${client.cif}`,
                        "title": "View Funds"
                    },{
                        "type": "postback",
                        "payload": `cif:report:${client.cif}`,
                        "title": "Summary Report"
                    }],
                }]
            }
        }
    }
    sendMessage(messageData, sender);
}

sendClientAccounts = (sender, accounts) => {
    accountCards = [];

    for(account in accounts) {
        var accountCard = {
            "title": `Allan Gray Investment Platform Unit Trust - ${accounts[account].number}`,
            "subtitle": `Market Value: ${accounts[account].networth}\n(as at ${accounts[account].lastUpdate})`,
            "buttons": [{
                "type": "postback",
                "payload": `accounts[account]:performance:${accounts[account].number}`,
                "title": "Performance"
            }, {
                "type": "postback",
                "payload": `accounts[account]:statement:${accounts[account].number}`,
                "title": "Account Statement"
            }],
        }
        accountCards.push(accountCard);
    }

    if(accountCards.length > 10) {
        accountCards.length = 10;
            //TODO: send another message if > 10
        }

        messageData = {
            "attachment": {
                "type": "template",
                "payload": {
                    "template_type": "generic",
                    "elements": accountCards
                }
            }
        }

        sendMessage(messageData, sender);
    }

    sendClientFunds = (sender, funds) => {
        fundCards = [];

        for(fund in funds) {
            var fundFollowLabel = "Follow";

            if(getFundPreferences(sender)[fund] !== undefined)
                if(getFundPreferences(sender)[fund] === "follow")
                    fundFollowLabel = "Unfollow";

                var currency = funds[fund]["currency_symbol"];
                var fundCard = {
                    "title": `${funds[fund]["name"]}`,
                    "subtitle": `Unit Price: ${currency} ${funds[fund]["price"]}\nUnits: ${funds[fund]["units"]}\nMarket value: ${currency} ${(funds[fund]["units"] * funds[fund]["price"]).toFixed(2)}\n(as at ${funds[fund]["lastUpdate"]})`,
                    "buttons": [{
                        "type": "postback",
                        "payload": `follow_fund:${fund}`,
                        "title": `${fundFollowLabel}`
                    }],
                }
                fundCards.push(fundCard);
            }

            if(fundCards.length > 10) {
                fundCards.length = 10;
            //TODO: send another message if > 10
        }

        messageData = {
            "attachment": {
                "type": "template",
                "payload": {
                    "template_type": "generic",
                    "elements": fundCards
                }
            }
        }

        sendMessage(messageData, sender);
    }

    sendMessage = (payload, sender) => {
        request({
            url: 'https://graph.facebook.com/v2.6/me/messages',
            qs: {access_token:appToken},
            method: 'POST',
            json: {
                recipient: {id:sender},
                message: payload,
            }
        }, (error, response, body) => {
            if (error) {
                console.log('Error sending messages: ', error)
            } else if (response.body.error) {
                console.log('Error: ', response.body.error)
            }
        });
    }

    getUserData = (user, callback) => {
        request({
            url: `https://graph.facebook.com/v2.6/${user}`,
            qs: {access_token:appToken},
            method: 'GET'
        }, (error, response, body) => {
            if (error) {
                console.log(`Error retreiving user data for: ${user}`, error)
                callback(undefined);
            } else if (response.body.error) {
                console.log('Error: ', response.body.error)
                callback(undefined);
            } else if (!error && response.statusCode == 200) {
                callback(body);
            }
        });
    }