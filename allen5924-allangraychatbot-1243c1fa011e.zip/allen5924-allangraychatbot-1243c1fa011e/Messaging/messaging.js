var fund_utils = require('../Funds/fund');
var fb_utils = require('./fbMessagingUtils');
var natural = require('natural');
var fund_utils = require('../Funds/fund');

var fundClassifierJSON = require('../fundClassifier.json')
var requestClassifierJSON = require('../requestClassifier.json')
var preferences = require('../Preferences/preferences');
var clients = require('../Client/client');

var usersLoginStatus = {}

userLoggedIn = (sender) => {
    return (usersLoginStatus[sender] === "linked");
}

processPayload = (payload, sender) => {
    payloadData = payload.split(':');
    if(payloadData[0] === 'cta')
        processQRPayload(payloadData[1], sender);
    else if(payloadData[0] === 'settings')
        processSettingsPayload(payloadData[1], sender);
    else if(payloadData[0] === 'cif')
        processCifPayload(payload, sender);
    else
        processPostbackPayload(payload, sender);
}

processQRPayload = (cta, sender) => {
    switch(cta) {
        case 'intro':
        getUserData(sender, (name) => {
            name = JSON.parse(name).first_name;
            typeof callback === 'function' ? sendGreeting(sender, name) : callback.send(`hello ${name}`);
        });
        break;

        case 'fund':
        sendTextMessage(sender, `For the latest fund information: type the fund name or fund code e.g. "AGBD" or "allan gray bond fund"`);
        break;

        case 'call_csc':
        sendCSCPhoneNumber(sender);
        break;

        case 'settings':
        sendSettings(sender);
        break;

        case 'subscriptions':
        sendTextMessage(sender, "Not Implemented Yet: coming soon!");
        break;

        case 'help':
        sendTextMessage(sender, "Not Implemented Yet: coming soon!");
        break;

        case 'insights':
        sendLatestNews(sender);
        break;

        case 'publications':
        sendLatestPublications(sender);
        break;

        case 'forms':
        sendFormOptions(sender)
        break;

        case 'adviser':
        if(userLoggedIn(sender))
            sendAccountLinkingLogout(sender);
        else
            sendAccountLinkingLogin(sender);
        break;

        default:
        sendTextMessage(sender, `ERROR: Quick Reply unknown (${cta})`);
        break;
    }

}

processSettingsPayload = (setting, sender) => {
    switch(setting) {
        case 'daily_update':
        if(!getPreferences(sender).time === undefined) {
            sendTextMessage(sender, `You are currently set to receive alert at ${getPreferences(sender).time}.`);
        } else {
            sendTextMessage(sender, "You currently do not receive daily alerts.");
        }

        setTimeout(() => {
            sendSettingTimeQuickReply(sender);
        }, 500);
        break;

        case 'fund_follows':
        sendFundsFollowed(sender);
        // sendTextMessage(sender, JSON.stringify(getFundPreferences(sender)))
        break;

        default:
        sendTextMessage(sender, `ERROR: Setting unknown (${setting})`);
        break;
    }
}

processClientCard = (cif, sender) => {
    client = getClient(cif);
    client["cif"] = cif;
    client["netWorth"] = "R 2 000 000"


    var d = new Date();
    client["lastUpdate"] = d.toLocaleDateString();
    //TODO: work out networth
    //TODO: work out last update
    sendClientCard(sender, client)
}

processClientAccounts = (cif, sender) => {
    accounts = getClientAccounts(cif);
    var d = new Date();

    for(account in accounts) {
        accounts[account]["number"] = account
        accounts[account]["networth"] = "R 1 000 000"
        accounts[account]["lastUpdate"] = d.toLocaleDateString();
    }

    sendClientAccounts(sender, accounts);
}

processClientFunds = (cif, sender) => {
    funds = {}
    clientFunds = getClientFunds(cif);

    for(fundCode in clientFunds) {
        console.log(fundCode);
        fund = findFundDataFromCode(fundCode);
        priceAndDate = getLatestPrice(fund);
        priceSplitLocation = priceAndDate.indexOf(" ");

        funds[fundCode] = {
            "name": fund.fund.name,
            "units": clientFunds[fundCode],
            "price": parseFloat(priceAndDate.substring(0, priceSplitLocation)),
            "currency_symbol": getCurrencySymbol(fund),
            "lastUpdate": priceAndDate.substring(priceSplitLocation + 2, priceAndDate.length - 1)
        }
    }

    sendClientFunds(sender, funds);
}

processCifPayload = (payload, sender) => {
    payloadData = payload.split(':');
    cif_req = payloadData[1];
    cif_number = payloadData[2];

    switch(cif_req) {
        case 'accounts':
        processClientAccounts(cif_number, sender);
        break;

        case 'funds':
        processClientFunds(cif_number, sender);
        break;

        case 'report':
        sendTextMessage(sender, "Not Implemented yet");
        break;

        default:
        sendTextMessage(sender, `ERROR: Setting unknown (${cif_req})`);
        break;
    }
}

processPostbackPayload = (payload, sender) => {
    payloadData = payload.split(':');

    switch(payloadData[0]) {
        case 'fund_info':
        requestedFund = findFundDataFromCode(payloadData[1]);
        sendFundPrice(sender, requestedFund);
        break;
       
        case 'factsheet':
        requestedFund = findFundDataFromCode(payloadData[1]);
        sendFundFactSheet(sender, requestedFund);
        break;

        case 'email': 
        sendTextMessage(sender, "Not Implemented Yet: coming soon! Click download in the meantime");
        break;

        case 'follow_fund':
        toggleFundPreference(sender, payloadData[1]);

        var action_outcome = "followed"
        if(getFundPreferences(sender)[payloadData[1]] === "unfollow")
            action_outcome = `un${action_outcome}`

        sendTextMessage(sender, `${payloadData[1]} successfully ${action_outcome}`);
        break;

        case 'daily_update':
        if(payloadData[1] === "delete") {
            removePreference(sender, "time");
            sendTextMessage(sender, "Daily update successfully turned off");
        }
        else {
            addPreference(sender, "time", payloadData[1]);
            sendTextMessage(sender, `Daily update time successfully updated to ${payloadData[1]}`);
        }
        break;

        default:
        sendTextMessage(sender, `ERROR: Postback unknown (${payload})`);
        break;
    }
}

processReceivedMessage = (request) => {
  var data = request.body;

  // Make sure this is a page subscription
  if (data.object == 'page') {
        // Iterate over each entry
        // There may be multiple if batched
        data.entry.forEach(function(pageEntry) {
          var pageID = pageEntry.id;
          var timeOfEvent = pageEntry.time;

          // Iterate over each messaging event
          pageEntry.messaging.forEach(function(messagingEvent) {
            var sender = messagingEvent.sender.id;
            if (messagingEvent.message) {
                if(messagingEvent.message.quick_reply)
                    processPayload(messagingEvent.message.quick_reply.payload, sender);
                else
                    interact(messagingEvent.message.text, sender, () => {});
            } else if (messagingEvent.postback) {
              processPayload(messagingEvent.postback.payload, sender);
          } else if (messagingEvent.delivery) {
            //message delivery callback
        } else if (messagingEvent.account_linking) {
            authUser(sender, messagingEvent.account_linking.status)
        } else {
          console.log("Webhook received unknown messagingEvent: ", messagingEvent);
      }
  });
      });
    }
}

authUser = (sender, loginStatus) => {
    usersLoginStatus[sender] = loginStatus;
    console.log(usersLoginStatus);
}

determineRequestType = (classifier, message) => {
    classifications = classifier.getClassifications(message);

    if(classifications.length > 0)
        return (classifications[0].value > 0.51) ? classifications[0].label : '';

    return undefined;
}

getFundCode = message => {
    foundFund = extractFundCodeFromText(message);
    if(foundFund !== undefined) {
        return foundFund;
    } else {
        fundClassifier = natural.BayesClassifier.restore(fundClassifierJSON);
        foundFundCode = determineFundCode(fundClassifier, message);
        if(typeof foundFundCode === 'string') {
            return findFundDataFromCode(foundFundCode)
        } else if (Array.isArray(foundFundCode)) {
            return foundFundCode;
        }
    }
}

interact = (message, sender, callback) => {
    requestClassifier = natural.LogisticRegressionClassifier.restore(requestClassifierJSON);
    requestType = determineRequestType(requestClassifier, message);

    if(message.length < 6) {
        var fund_code = extractFundCodeFromText(message);
        if(fund_code !== undefined)
            requestType = 'fund_info';
    }

    if(message.toLowerCase().includes("cif"))
        requestType = 'cif_request';

    switch (requestType) {
        case 'fund_info':
        fund = getFundCode(message);
        typeof callback === 'function' ? (Array.isArray(fund) ? sendFoundFundOptions(sender, fund, requestType) : sendFundPrice(sender, fund)) : callback.send(fund);
        break;

        case 'form':
        typeof callback === 'function' ? sendFormOptions(sender) : callback.send("forms");
        break;

        case 'news':
        typeof callback === 'function' ? sendLatestNews(sender) : callback.send("news");
        break;

        case 'publications':
        typeof callback === 'function' ? sendLatestPublications(sender) : callback.send("publications");
        break;

        case 'greeting':
        getUserData(sender, (name) => {
            name = JSON.parse(name).first_name;
            typeof callback === 'function' ? sendGreeting(sender, name) : callback.send(`hello ${name}`);
        });
        break;

        case 'cif_request':
        if(userLoggedIn(sender)) {
            cif = message.match('[0-9]+');
            client = getClient(cif);

            if(client === undefined)
                typeof callback === 'function' ? sendTextMessage(sender, `Cannot find client with cif number: ${cif}`) : callback.send(`Cannot find client with cif number: ${cif}`);
            else {
                typeof callback === 'function' ? processClientCard(cif, sender) : callback.send(`recieved cif: ${cif}`);
            }
        } else {
            sendTextMessage(sender, `You are not logged in, you do not have authorisation to search for clients.\nPlease login and try again.`);
            setTimeout(() => {
                sendAccountLinkingLogin(sender);
            }, 500);
        }
        break;

        case 'acc_request': 
        if(userLoggedIn(sender)) {
            processClientCard(0000, sender)
        } else {
            sendTextMessage(sender, `You are not logged in and cannot view your account info. \nPlease login and try again.`);
            setTimeout(() => {
                sendAccountLinkingLogin(sender);
            }, 500);
        }
        break;
        

        default:
        typeof callback === 'function' ? sendApology(sender) : callback.send("unknown request type");
        break;
    }
}