var natural = require('natural')

formClassifier = new natural.BayesClassifier();

classifier = function doClassification() {
	//Forms
	//Unit Trusts
	formClassifier.addDocument('Application for individual investors (Allan Gray Unit Trust)', '');
	formClassifier.addDocument('Application for individual investors (Allan Gray Investment Platform)', '');
	formClassifier.addDocument('Application for legal entities (Allan Gray Unit Trust)', '');
	formClassifier.addDocument('Application for legal entities (Allan Gray Investment Platform)', '');
	formClassifier.addDocument('Acting on behalf of the investor', '');
	formClassifier.addDocument('Additional contribution', '');
	formClassifier.addDocument('Debit order', '');
	formClassifier.addDocument('Phase-in', '');
	formClassifier.addDocument('Switch', '');
	formClassifier.addDocument('Withdrawal', '');
	formClassifier.addDocument('Internal transfer instruction', '');
	formClassifier.addDocument('Security cession notice', '');
	formClassifier.addDocument('Unit transfer to the Allan Gray Investment Platform', '');
	formClassifier.addDocument('Joint address declaration', '');
	formClassifier.addDocument('Rebalance instruction', '');

	//Unit Trust FYI
	formClassifier.addDocument('Terms and conditions (Allan Gray Unit Trust)', '');
	formClassifier.addDocument('Terms and conditions (Allan Gray Investment Platform)', '');
	formClassifier.addDocument('Local fund list', '');
	formClassifier.addDocument('Characteristics and objectives', '');

	
	//RA fund	
	formClassifier.addDocument('Application', '');
	formClassifier.addDocument('Acting on behalf of the investor', '');
	formClassifier.addDocument('Additional contribution', '');
	formClassifier.addDocument('Debit order', '');
	formClassifier.addDocument('Switch', '');
	formClassifier.addDocument('Rebalance instruction', '');
	formClassifier.addDocument('Phase-in', '');
	formClassifier.addDocument('Withdrawal', '');
	formClassifier.addDocument('Retirement notification', '');
	formClassifier.addDocument('Change in nomination details of beneficiaries', '');
	formClassifier.addDocument('Request for approval of early retirement', '');
	formClassifier.addDocument('Annual Fee renewal instruction', '');

	//RA fund FYI
	formClassifier.addDocument('Conditions of membership', '');
	formClassifier.addDocument('Understanding the death claims process of retirement funds', '');
	formClassifier.addDocument('Annual Fee renewal instruction', '');


	//TFIA
    formClassifier.addDocument('Change in details of beneficiaries for the Allan Gray Tax-Free Investment', '');
    formClassifier.addDocument('Tax-Free Investment withdrawal instruction', '');
    formClassifier.addDocument('Acting on behalf of the investor', '');
    formClassifier.addDocument('Change in investor details', '');
    formClassifier.addDocument('Tax-Free Investment unit trust list', '');
    formClassifier.addDocument('Terms and conditions', '');


    //Living Annuity
    formClassifier.addDocument('Application', '');
    formClassifier.addDocument('Acting on behalf of the investor', '');
    formClassifier.addDocument('Additional contribution', '');
    formClassifier.addDocument('Withdrawal', '');
    formClassifier.addDocument('Switch', '');
    formClassifier.addDocument('Phase-in', '');
    formClassifier.addDocument('Change in details of beneficiary', '');

    //Living Annuity FYI
    formClassifier.addDocument('Terms and conditions', '');


    //Pension and Provident Preservation Funds
    formClassifier.addDocument('Phase-in', '');
    formClassifier.addDocument('Application', '');
    formClassifier.addDocument('Acting on behalf of the investor', '');
    formClassifier.addDocument('Switch', '');
    formClassifier.addDocument('Rebalance instruction', '');
    formClassifier.addDocument('Withdrawal', '');
    formClassifier.addDocument('Retirement notification', '');
    formClassifier.addDocument('Change in nomination details of beneficiaries', '');
    formClassifier.addDocument('Request for approval of early retirement', '');

    //Pension and Provident Preservation Funds
    formClassifier.addDocument('Conditions of membership for the Pension Preservation Fund', '');
    formClassifier.addDocument('Conditions of membership for the Provident Preservation Fund', '');
    formClassifier.addDocument('Understanding the death claims process of retirement funds', '');


    //Endowment
    formClassifier.addDocument('Application for individual investors', '');
    formClassifier.addDocument('Application for legal entities', '');
    formClassifier.addDocument('Acting on behalf of the investor', '');
    formClassifier.addDocument('Additional contribution', '');
    formClassifier.addDocument('Debit order', '');
    formClassifier.addDocument('Withdrawal', '');
    formClassifier.addDocument('Switch', '');
    formClassifier.addDocument('Phase-in', '');
    formClassifier.addDocument('Outright cession', '');
    formClassifier.addDocument('Security cession notice', '');
    formClassifier.addDocument('Change in details of beneficiaries', '');
    formClassifier.addDocument('Joint address declaration', '');

    //Endowment FYI
    formClassifier.addDocument('Terms and conditions', '');


    // MANY MANY MORE.....


	formClassifier.train();
	formClassifier.save('formClassifier.json', (err, classifier) => {});


}

module.exports = classifier