var natural = require('natural')

fundClassifier = new natural.BayesClassifier();

classifier = function doClassification() {
	//Funds
	fundClassifier.addDocument('Allan Gray Africa ex-SA Equity Fund', 'AGAEX');
	fundClassifier.addDocument('Allan Gray Australia Equity Fund', 'SMEF');
	fundClassifier.addDocument('Allan Gray Australia Opportunity Fund', 'SMSF');
	fundClassifier.addDocument('Allan Gray Equity Fund', 'AGEF');
	fundClassifier.addDocument('Allan Gray SA Equity Fund', 'AGDA');
	fundClassifier.addDocument('Allan Gray Balanced Fund', 'AGBF');
	fundClassifier.addDocument('Allan Gray Tax-Free Balanced Fund', 'AGTBA');
	fundClassifier.addDocument('Allan Gray Stable Fund', 'AGSF');
	fundClassifier.addDocument('Allan Gray Optimal Fund', 'AGOF');
	fundClassifier.addDocument('Allan Gray Bond Fund', 'AGBD');
	fundClassifier.addDocument('Allan Gray Money Market Fund', 'AGMF');
	fundClassifier.addDocument('Allan Gray Orbis Global Equity Feeder Fund', 'AGOE');
	fundClassifier.addDocument('Allan Gray Orbis Global Fund of Funds', 'AGGF');
	fundClassifier.addDocument('Allan Gray Orbis Global Optimal Fund of Funds', 'AGOO');

	fundClassifier.addDocument('27four Shari\'ah Balanced Prescient Fund of Funds', '27SA1');
	
	fundClassifier.addDocument('36ONE MET Equity Fund', 'MNTR');

	fundClassifier.addDocument('Ashburton Replica Dollar Asset Management Fund', 'ARUSD');
	fundClassifier.addDocument('Ashburton Replica Euro Asset Management Fund', 'AREUD');
	fundClassifier.addDocument('Ashburton Replica Sterling Asset Management Fund', 'ARGBD');

	fundClassifier.addDocument('Catalyst Global Real Estate UCITS Fund', 'CGREF');

	fundClassifier.addDocument('Coronation Balanced Defensive Fund', 'COBA');
	fundClassifier.addDocument('Coronation Balanced Plus Fund', 'CORB');
	fundClassifier.addDocument('Coronation Capital Plus Fund', 'CCPF');
	fundClassifier.addDocument('Coronation Global Capital Plus [ZAR] Feeder Fund', 'COLA');
	fundClassifier.addDocument('Coronation Global Capital Plus Fund', 'CGCG');
	fundClassifier.addDocument('Coronation Global Emerging Markets Fund', 'CGEB');
	fundClassifier.addDocument('Coronation Global Capital Plus Fund', 'CGCUH');
	fundClassifier.addDocument('Coronation Global Emerging Markets Flexible [ZAR] Fund', 'CGEM');
	fundClassifier.addDocument('Coronation Global Equity Select Fund', 'CGESP');
	fundClassifier.addDocument('Coronation Global Managed Fund', 'CGMA');
	fundClassifier.addDocument('Coronation Global Managed [ZAR] Feeder Fund', 'COGM');
	fundClassifier.addDocument('Coronation Global Opportunities Equity Fund', 'CGOE');
	fundClassifier.addDocument('Coronation Global Strategic Income Fund', 'CGSU');
	fundClassifier.addDocument('Coronation Optimum Growth Fund', 'CNOG');
	fundClassifier.addDocument('Coronation Strategic Income Fund', 'CSIF');
	fundClassifier.addDocument('Coronation Top 20 Fund', 'CNTF');
	fundClassifier.addDocument('Coronation Global Opportunities Equity [ZAR] Feeder Fund', 'CNIG');

	fundClassifier.addDocument('Dodge & Cox Worldwide Global Stock Fund', 'DCGSF');

	fundClassifier.addDocument('Fidelity Funds European Growth Fund ', 'YEUG');
	fundClassifier.addDocument('Fidelity Funds Emerging Markets Fund ', 'YEMM');
	fundClassifier.addDocument('Fidelity Funds World Fund ', 'YWLDY');

	fundClassifier.addDocument('Foord Balanced Fund (Class B2)', 'FBCB2');
	fundClassifier.addDocument('Foord Balanced Fund (Class B4)', 'FOCB4');
	fundClassifier.addDocument('Foord Conservative Fund', 'FCFB2');
	fundClassifier.addDocument('Foord Equity Fund (Class B2)', 'FECB2');
	fundClassifier.addDocument('Foord Equity Fund (Class B4)', 'FECB4');
	fundClassifier.addDocument('Foord Flexible Fund of Funds (Class B2)', 'FFCB2');
	fundClassifier.addDocument('Foord Flexible Fund of Funds Class B4)', 'FUFB4');
	fundClassifier.addDocument('Foord Global Equity Fund', 'FGEFS');
	fundClassifier.addDocument('Foord International Feeder Fund', 'FIFB2');
	fundClassifier.addDocument('Foord International Fund', 'FIFL');

	fundClassifier.addDocument('FTIF Templeton Asian Growth Fund ', 'FAGC');
	fundClassifier.addDocument('FTIF Templeton Emerging Markets Fund ', 'FEMC');
	fundClassifier.addDocument('FTIF Templeton Global Balanced Fund ', 'FTGB');
	fundClassifier.addDocument('FTIF Franklin US Opportunities Fund ', 'FUOF');

	fundClassifier.addDocument('GinsGlobal Global Bond Index Fund', 'GGBI');
	fundClassifier.addDocument('GinsGlobal Global Equity Index Fund', 'GGEI');

	fundClassifier.addDocument('Investec Cautious Managed Fund', 'CMFH');
	fundClassifier.addDocument('Investec Diversified Income Fund', 'IDICH');
	fundClassifier.addDocument('Investec Equity Fund (Class H)', 'EQTH');
	fundClassifier.addDocument('Investec Equity Fund (Class E)', 'EQTE');
	fundClassifier.addDocument('Investec Global Franchise Feeder Fund', 'GLOH');
	fundClassifier.addDocument('Investec Global Franchise Fund', 'IFRC');
	fundClassifier.addDocument('Investec Global Strategic Equity Fund', 'ISEC');
	fundClassifier.addDocument('Investec Global Strategic Managed Fund', 'ISMC');
	fundClassifier.addDocument('Investec Global Strategic Managed Feeder Fund', 'GBFH');
	fundClassifier.addDocument('Investec Managed Fund', 'MANH');
	fundClassifier.addDocument('Investec Opportunity Fund', 'OPPE');
	fundClassifier.addDocument('Investec Sterling Money Fund', 'IGBM');
	fundClassifier.addDocument('Investec US Dollar Money Fund', 'IUSM');
	fundClassifier.addDocument('Investec Value Fund (Class H)', 'VALH');
	fundClassifier.addDocument('Investec Value Fund (Class E)', 'VALE');

	fundClassifier.addDocument('Kagiso Islamic Balanced Fund', 'KAIB');
	fundClassifier.addDocument('Kagiso Islamic Equity Fund', 'KAIE');
	fundClassifier.addDocument('M&G Recovery Fund ', 'MGRF');

	fundClassifier.addDocument('Marriott Dividend Growth Fund', 'HLMK');
	fundClassifier.addDocument('Marriott International Real Estate Fund', 'MIRE');

	fundClassifier.addDocument('Nedgroup Investments Flexible Income Fund', 'NIFA');
	fundClassifier.addDocument('Nedgroup Investments Global Cautious Feeder Fund', 'NEGC');
	fundClassifier.addDocument('Nedgroup Investments Global Cautious Fund', 'NIGCF');
	fundClassifier.addDocument('Nedgroup Investments Global Flexible Feeder Fund', 'BOEB');
	fundClassifier.addDocument('Nedgroup Investments Global Flexible Fund', 'NGBF');
	fundClassifier.addDocument('Nedgroup Investments Global Equity Feeder Fund', 'AHGV');
	fundClassifier.addDocument('Nedgroup Investments Global Equity Fund', 'NIGE');
	fundClassifier.addDocument('Nedgroup Investments Opportunity Fund', 'NIOB');
	fundClassifier.addDocument('Nedgroup Investments Property Fund', 'NIPCA');
	fundClassifier.addDocument('Nedgroup Investments Stable Fund', 'NISCC');
	fundClassifier.addDocument('Nedgroup Investments Core Diversified Fund', 'NIDCB');
	fundClassifier.addDocument('Nedgroup Investments Core Guarded Fund', 'NICCB');

	fundClassifier.addDocument('Old Mutual Global Equity Fund', 'OMGB1');

	fundClassifier.addDocument('Orbis Global Equity Fund', 'OGEF');
	fundClassifier.addDocument('Orbis SICAV Asia Ex-Japan Equity Fund', 'XJEF');
	fundClassifier.addDocument('Orbis SICAV Japan Equity Fund', 'OJEU');
	fundClassifier.addDocument('Orbis SICAV Japan Equity Fund', 'OJEF');
	fundClassifier.addDocument('Orbis SICAV Global Balanced Fund', 'GBSAI');
	fundClassifier.addDocument('Orbis Optimal SA Fund (EUR)', 'OSAE');
	fundClassifier.addDocument('Orbis Optimal SA Fund (USD)', 'OSAD');

	fundClassifier.addDocument('Prescient Income Provider Fund', 'PIPF');

	fundClassifier.addDocument('Prudential Balanced Fund', 'PRBCX');
	fundClassifier.addDocument('Prudential Dividend Maximiser Fund', 'PRUM');
	fundClassifier.addDocument('Prudential Enhanced SA Property Tracker Fund', 'PEPI');
	fundClassifier.addDocument('Prudential Equity Fund', 'PRUO');
	fundClassifier.addDocument('Prudential Inflation Plus Fund', 'PIPCX');

	fundClassifier.addDocument('PSG Balanced Fund', 'PBFE');
	fundClassifier.addDocument('PSG Flexible Fund', 'PSGO');

	fundClassifier.addDocument('Prescient RECM Global Feeder Fund', 'PRGFD');

	fundClassifier.addDocument('RECM Global Fund', 'REGC');

	fundClassifier.addDocument('Rezco Managed Plus Fund', 'RPFCC');
	fundClassifier.addDocument('Rezco Value Trend Fund', 'RVTCC');

	fundClassifier.addDocument('Sarasin IE GlobalSar - Dynamic (USD)', 'SBUC');
	fundClassifier.addDocument('Sarasin IE GlobalSar - Dynamic (GBP)', 'SBGC');
	fundClassifier.addDocument('Sarasin IE Real Estate Equity  - Global ', 'SREC');

	fundClassifier.addDocument('Satrix ALSI Index Fund', 'SLIB2');
	fundClassifier.addDocument('Satrix MSCI World Equity Index Feeder Fund', 'SWEB2');

	fundClassifier.addDocument('STANLIB Global Balanced Cautious Fund', 'SBCF');
	fundClassifier.addDocument('STANLIB Global Bond Fund', 'SGOB');

	fundClassifier.addDocument('Truffle MET Flexible Fund', 'TRFCC');

	fundClassifier.addDocument('Vulcan Value Equity Fund ', 'VVEF');
	
	fundClassifier.train();
	fundClassifier.save('fundClassifier.json', (err, classifier) => {});
}

module.exports = classifier