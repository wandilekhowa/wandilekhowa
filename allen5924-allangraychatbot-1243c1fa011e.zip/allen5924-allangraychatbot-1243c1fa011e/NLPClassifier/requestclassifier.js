var natural = require('natural')

requestClassifier = new natural.LogisticRegressionClassifier();

classifier = function doClassification() {
	//Greetings
	requestClassifier.addDocument('hello', 'greeting');
	requestClassifier.addDocument('hi', 'greeting');
	requestClassifier.addDocument('how are you', 'greeting');
	requestClassifier.addDocument('help me', 'greeting');
	requestClassifier.addDocument('I need help', 'greeting');
	requestClassifier.addDocument('assist me', 'greeting');
	requestClassifier.addDocument('hey', 'greeting');
	
	//Request for Fund Info
	requestClassifier.addDocument('what is the fund price for', 'fund_info');
	requestClassifier.addDocument('how much is', 'fund_info');
	requestClassifier.addDocument('unit price of', 'fund_info');
	requestClassifier.addDocument('give me the cost of', 'fund_info');
	requestClassifier.addDocument('today\'s price' , 'fund_info');
	requestClassifier.addDocument('how is the fund doing today', 'fund_info');
	requestClassifier.addDocument('what does it cost for', 'fund_info');
	requestClassifier.addDocument('I need information on', 'fund_info');
	requestClassifier.addDocument('fact sheet for', 'fund_info');
	requestClassifier.addDocument('factsheet for', 'fund_info');
	requestClassifier.addDocument('past performance', 'fund_info');
	requestClassifier.addDocument('commentary on fund', 'fund_info');
	requestClassifier.addDocument('fund info', 'fund_info');

	//infer from asset manager names
	requestClassifier.addDocument('Allan Gray', 'fund_info');
	requestClassifier.addDocument('27four', 'fund_info');
	requestClassifier.addDocument('36ONE', 'fund_info');
	requestClassifier.addDocument('Ashburton', 'fund_info');
	requestClassifier.addDocument('Catalyst', 'fund_info');
	requestClassifier.addDocument('Coronation', 'fund_info');
	requestClassifier.addDocument('Dodge & Cox', 'fund_info');
	requestClassifier.addDocument('Fidelity', 'fund_info');
	requestClassifier.addDocument('Foord', 'fund_info');
	requestClassifier.addDocument('FTIF ', 'fund_info');
	requestClassifier.addDocument('GinsGlobal', 'fund_info');
	requestClassifier.addDocument('Investec', 'fund_info');
	requestClassifier.addDocument('Kagiso', 'fund_info');
	requestClassifier.addDocument('M&G', 'fund_info');
	requestClassifier.addDocument('Marriott', 'fund_info');
	requestClassifier.addDocument('Nedgroup', 'fund_info');
	requestClassifier.addDocument('Old Mutual', 'fund_info');
	requestClassifier.addDocument('Orbis', 'fund_info');
	requestClassifier.addDocument('Prescient', 'fund_info');
	requestClassifier.addDocument('Prudential', 'fund_info');
	requestClassifier.addDocument('PSG', 'fund_info');
	requestClassifier.addDocument('Prescient', 'fund_info');
	requestClassifier.addDocument('RECM', 'fund_info');
	requestClassifier.addDocument('Rezco', 'fund_info');
	requestClassifier.addDocument('Sarasin', 'fund_info');
	requestClassifier.addDocument('Satrix', 'fund_info');
	requestClassifier.addDocument('STANLIB', 'fund_info');
	requestClassifier.addDocument('Truffle', 'fund_info');
	requestClassifier.addDocument('Vulcan', 'fund_info');

	//Request for Forms
	requestClassifier.addDocument('give me the form for', 'form');
	requestClassifier.addDocument('I need the application', 'form');
	requestClassifier.addDocument('sending an instruction', 'form');
	requestClassifier.addDocument('send me', 'form');
	requestClassifier.addDocument('give me the document for', 'form');
	requestClassifier.addDocument('i need the document', 'form');

	//Request for Insights (News)
	requestClassifier.addDocument('latest insight', 'news');
	requestClassifier.addDocument('latest news', 'news');
	requestClassifier.addDocument('latest blog', 'news');
	requestClassifier.addDocument('blogpost', 'news');
	requestClassifier.addDocument('blog', 'news');
	requestClassifier.addDocument('updates', 'news');
	requestClassifier.addDocument('what can I read', 'news');
	requestClassifier.addDocument('news', 'news');
	requestClassifier.addDocument('something to read', 'news');

	//Request for publications
	requestClassifier.addDocument('quarterly commentary', 'publications');
	requestClassifier.addDocument('grayissue', 'publications');
	requestClassifier.addDocument('annual report', 'publications');
	requestClassifier.addDocument('publications', 'publications');

	//Request for client info
	requestClassifier.addDocument('cif', 'cif_request');
	requestClassifier.addDocument('cif no.', 'cif_request');
	requestClassifier.addDocument('cif number', 'cif_request');
	requestClassifier.addDocument('client number', 'cif_request');
	requestClassifier.addDocument('customer number', 'cif_request');
	requestClassifier.addDocument('customer', 'cif_request');
	requestClassifier.addDocument('give me statements for client', 'cif_request');
	requestClassifier.addDocument('client account', 'cif_request');
	requestClassifier.addDocument('customer account', 'cif_request');

	//Request for client info
	requestClassifier.addDocument('my balance', 'acc_request');
	requestClassifier.addDocument('investment value', 'acc_request');
	requestClassifier.addDocument('investment report', 'acc_request');
	requestClassifier.addDocument('my net worth', 'acc_request');
	requestClassifier.addDocument('how much do I have', 'acc_request');

	requestClassifier.train();
	requestClassifier.save('requestClassifier.json', (err, classifier) => {});
}

module.exports = classifier