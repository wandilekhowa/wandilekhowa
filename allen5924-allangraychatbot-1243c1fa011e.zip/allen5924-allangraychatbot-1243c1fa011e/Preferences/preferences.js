var prefs = {
	// "1199622556754558" : {
	// 	funds: {"AGEF": "follow"},
	// 	time: "10h00"
	// }
};

getPreferences = (user) => {
	initisalisePreferencesForUser(user);

	return prefs[user];
}

addPreference = (user, pref, value) => {
	initisalisePreferencesForUser(user);

	prefs[user][pref] = value;
}

removePreference = (user, pref) => {
	initisalisePreferencesForUser(user);

	delete prefs[user][pref];
}

getFundPreferences = (user) => {
	initisalisePreferencesForUser(user);
	return prefs[user].funds
}

toggleFundPreference = (user, fundCode) => {
	initisalisePreferencesForUser(user);

	if(prefs[user].funds[fundCode] === undefined)
		prefs[user].funds[fundCode] = "follow"
	else {
		if(prefs[user].funds[fundCode] === "follow") {
			prefs[user].funds[fundCode] = "unfollow"
		}
		else {
			prefs[user].funds[fundCode] = "follow"
		}
	}
}

initisalisePreferencesForUser = (user) => {
	if(prefs[user] === undefined) {
		prefs[user] = {}
		addPreference(user, "funds", {});
	}
}