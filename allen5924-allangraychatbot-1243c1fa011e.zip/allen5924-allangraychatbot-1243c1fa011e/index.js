var express = require('express');
var bodyParser = require('body-parser');
var messaging = require('./Messaging/messaging');
var fb_utils = require('./Messaging/fbMessagingUtils');
var Mustache = require('mustache');
var _ = require('lodash');

var app = express();

app.set('port', (process.env.PORT || 5000));
app.set('views', __dirname + '/views');
app.set('view engine', 'pug');

app.use(express.static(__dirname + '/resources'));


// Process application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: false}));

// Process application/json
app.use(bodyParser.json());

//////// ROUTES ///////// 
// Index Route
app.get('/', (req, res) => {
	res.send('Hello world, I am the Allan Gray chat bot');
});

// Test Route
app.get('/test/', (req, res) => {
    text = '';

    if(req._parsedUrl.query)
        text = decodeURIComponent(req._parsedUrl.query);

    interact(text, null, res);
});

// Train natural language processor classifiers
app.get('/train_requests/', (req, res) => {
    var reqClassifier = require('./NLPClassifier/requestclassifier');
    new classifier();

    res.send('Request training complete, JSON updated!');
});

app.get('/train_funds/', (req, res) => {
    var fundClassifier = require('./NLPClassifier/fundclassifier')
    new classifier();

    res.send('Fund training complete, JSON updated!');
});

app.get('/train_forms/', (req, res) => {
    var formClassifier = require('./NLPClassifier/formclassifier')
    new classifier();

    res.send('Form training complete, JSON updated!');
});

app.post('/webhook/', (req, res) => {
    processReceivedMessage(req)
    res.sendStatus(200);
});

app.get('/name/', (req, res) => {
    text = '';

    if(req._parsedUrl.query)
        text = decodeURIComponent(req._parsedUrl.query);

    getUserData(text, (name) => {
        name = JSON.parse(name).first_name;
        res.send(name)
    });
});

app.get('/login/', (req, res) => {
    var url = require('url');
    var url_parts = url.parse(req.url, true);
    var query = url_parts.query;

    //TODO: pass queries through to login button - template it for demo
    if(query.account_linking_token === undefined || query.redirect_uri === undefined)
        res.redirect(403, "https://www.allangray.co.za");

    var auth_qs = '&authorization_code=AUTHORIZATION_CODE'

    res.render('login', { url: query.redirect_uri + auth_qs });
});

// app.get('/funds/', (req, res) => {
//     var funds = require('./funds.json');
//     var returnedFunds = {};
//     funds.forEach(function(part, ind, arr) {
//         var fundJSON = arr[ind];
//         if(!returnedFunds[fundJSON.fund.aciFundClassAssetClass])
//             returnedFunds[fundJSON.fund.aciFundClassAssetClass] = [];
        
//         if(returnedFunds[fundJSON.fund.])
//         returnedFunds[fundJSON.fund.aciFundClassAssetClass].push(fundJSON.fund.name);
//     });

//     res.send(returnedFunds);
// });

// var currencySymbols = {
//     "ZAR" : "R",
//     "USD" : "$",
//     "AUD" : "$",
//     "GBP" : "£",
//     "JPY" : "¥",
//     "EUR" : "€"
// }

// app.get('/genFundCardIMGs/', (req, res) => {
//     var util = require('util')
//     var exec = require('child_process').exec;
//     var funds = require('./funds.json');
//     var fs = require('fs');
//     var wkhtmltoimage = require('wkhtmltoimage');

//     function puts(error, stdout, stderr) { 
//         res.send("success")
//     }

//     fs.readFile('./fundPriceImageTemplate.html', (err, html) => {
//         if (err) {
//             throw err; 
//         }
//         funds.forEach(function(part, ind, arr) {
//             var data = {};
//             var fundJSON = arr[ind];
//             var fundName = fundJSON.fund.name.replace(new RegExp("\\s\\([A-Za-z0-9\\s]*\\)", 'g'), '');
//             fundName = fundName.replace(' [ZAR] ', '');
//             var prices = _.values(fundJSON.pricesInCents);

//             prices.forEach(function(part, ind, arr) {
//                 arr[ind] = (arr[ind] / 100).toFixed(2);
//             });

//             Object.assign(data, {
//                 "name" : fundName
//             });

//             Object.assign(data, {
//                 "code": fundJSON.fund.displayCode
//             });

//             Object.assign(data, {
//                 "prices": prices
//             });

//             Object.assign(data, {
//                 "currencySymbol": currencySymbols[fundJSON.fund.currency]
//             });

//             Object.assign(data, {
//                 "minPrice": _.min(prices)
//             });
//             Object.assign(data, {
//                 "maxPrice": _.max(prices)
//             });

//             Object.assign(data, {
//                 "startPrice": prices[0]
//             });

//             Object.assign(data, {
//                 "endPrice": prices[prices.length - 1]
//             });

//             Object.assign(data, {
//                 "percentageChange" : ((data.endPrice - data.startPrice) / data.endPrice).toFixed(3)
//             })

//             dates = _.keys(fundJSON.pricesInCents);

//             Object.assign(data, {
//                 "asAt": (new Date(dates[dates.length - 1]).toString().substring(0, new Date().toString().indexOf(':') - 3))
//             })

//             Object.assign(data, {
//                 "weeks": Math.ceil(Math.abs(new Date(dates[dates.length - 1]).getTime() - 
//                     new Date(dates[0]).getTime()) / (1000 * 3600 * 24 * 7)),
//             })

//             //Stringify Dates
//             dates.forEach(function(part, ind, arr) {
//                 arr[ind] = "'" + arr[ind].substring(5) + "'";
//             });

//             Object.assign(data, {
//                 "dates": dates
//             });

//             wkhtmltoimage.generate(Mustache.render(html.toString(), data), { output: `fundPNGs/${arr[ind].fund.displayCode}.jpg`, height: 524, width: 1000, });
//         });
//     });
// });
///////////////////////////

app.listen(app.get('port'), () => {
	console.log('running on port', app.get('port'));
})